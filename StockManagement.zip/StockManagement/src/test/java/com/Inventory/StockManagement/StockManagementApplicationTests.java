package com.Inventory.StockManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
